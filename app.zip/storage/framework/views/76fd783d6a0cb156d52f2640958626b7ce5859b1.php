<div id="preloader">
    <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
<?php /**PATH C:\OpenServer\domains\blog-2-20\resources\views/components/Preloader.blade.php ENDPATH**/ ?>